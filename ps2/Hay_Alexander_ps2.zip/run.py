#!/usr/bin/env python2

"""
This does the homework
"""

import os

os.system('python ps2-1.py')
os.system('python ps2-2.py')
os.system('python ps2-3.py')
